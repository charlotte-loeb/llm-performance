library(tidyverse)
party_codebook <- tribble(~code, ~region, ~label,
  "1","GER","CDU/CSU","2","GER","SPD","3","GER","Die Linke","4","GER","Gruene (GER)",
  "5","GER","AfD","6","GER","FDP","7","GER","Other (GER)",
  "8","SUI","BDP","9","SUI","CVP","10","SUI","CSP","11","SUI","EVP","12","SUI","FDP.Die Liberalen",
  "13","SUI","GPS","14","SUI","GLP","15","SUI","Lega","16","SUI","MCR/MCG","17","SUI","SVP",
  "18","SUI","SP (SUI)","19","SUI","Other (SUI)",
  "20","USA","Democrats","21","USA","Republicans","22","USA","Other (USA)",
  "23","AUS","Liberal Party of Australia","24","AUS","ALP","25","AUS","The Nationals",
  "26","AUS","Australian Greens","27","AUS","Other (AUS)",
  "28","LEB","Courant du Futur","29","LEB","PSP","30","LEB","Lebanese Forces",
  "31","LEB","Kataeb","32","LEB","PNL","33","LEB","Mouvement renouveau democratique",
  "34","LEB","MDG","35","LEB","Amal","36","LEB","Hezbollah","37","LEB","PSNS",
  "38","LEB","CPL (FPM)","39","LEB","Other (LEB)",
  "40","TUR","AKP","41","TUR","CHP","42","TUR","MHP","43","TUR","HDP","44","TUR","Other (TUR)",
  "45","-","No party affiliation","-99","-","Not specified"
) |> mutate(code = as.character(code))

country_region <- c("1"="AUS","2"="SUI","3"="GER","4"="LEB","5"="TUR","6"="USA")

norm <- function(s) {
  s <- tolower(iconv(enc2utf8(s), "UTF-8", "ASCII//TRANSLIT"))
  s <- str_replace_all(s, "[^a-z0-9 ]", " ")
  s <- str_remove_all(s, "\\b(party|partei|partisi|der|die|de|du|la|le|les|of|the|and|und|e)\\b")
  str_squish(s)
}

alias <- tribble(~pattern, ~code, ~region,
  "afd|alternative fur deutschland","5",NA,
  "cdu|csu","1",NA,
  "spd|sozialdemokratische partei deutsch","2",NA,
  "linke","3",NA,
  "bundnis|die grunen|grune partei bundnis","4","GER",
  "grune|grunen|greens|green party","26","AUS",
  "grune|grunen|greens|green party","13","SUI",
  "grunliberale|glp","14","SUI",
  "fdp|freie demokraten|freie demokratische","6","GER",
  "fdp|liberalen|fdp die liberalen","12","SUI",
  "liberal party|liberals|liberal","23","AUS",
  "bdp","8","SUI",
  "cvp|christlichdemokratische|christian democratic people","9","SUI",
  "csp","10","SUI","evp|evangelische volkspartei","11","SUI",
  "svp|schweizerische volkspartei|swiss people","17","SUI",
  "\\bsp\\b|social democratic party of switzerland|schweizerische sozialdemokratische|sp/","18","SUI",
  "mcr|mcf|mouvement citoyens","16","SUI","lega ticinesi","15","SUI",
  "democratic party|democrats","20","USA",
  "republican|gop|grand old party","21","USA",
  "australian labor|\\blabor\\b|alp","24","AUS",
  "national party|nationals","25","AUS",
  "courant du futur|future movement","28","LEB",
  "socialiste progressiste|\\bpsp\\b","29","LEB",
  "forces libanaises|lebanese forces|\\blfp\\b|القوات اللبنانية","30","LEB",
  "kataeb|kata'ib|al-kataib|phalange|الكتائب","31","LEB",
  "national liberal|\\bpnl\\b","32","LEB",
  "renouveau democratique","33","LEB",
  "gauche democratique|\\bmdg\\b","34","LEB",
  "amal|depossedes","35","LEB",
  "hezbollah|parti de dieu","36","LEB",
  "socialiste syrien|\\bpsns\\b","37","LEB",
  "patriotique libre|free patriotic|\\bcpl\\b|التيار الوطني الحر|التغيير والاصلاح|change and reform","38","LEB",
  "hunchak|hanshaq|ramgavar","39","LEB",
  "akp|adalet ve kalkinma","40","TUR",
  "chp|cumhuriyet halk","41","TUR",
  "mhp|milliyetci hareket","42","TUR",
  "hdp|halklarin demokratik","43","TUR",
  "no party","45",NA
)

harmonize_party <- function(value, region) {
  out <- rep(NA_character_, length(value))
  meth <- rep("blank", length(value))
  for (i in seq_along(value)) {
    v <- value[i]; r <- region[i]
    if (is.na(v) || str_trim(v) == "") { meth[i] <- "blank"; next }
    vt <- str_trim(v)
    if (str_detect(vt, "^-99")) { out[i] <- "-99"; meth[i] <- "code"; next }
    if (str_detect(tolower(vt), "no party")) { out[i] <- "45"; meth[i] <- "code"; next }
    num <- str_extract(vt, "^-?\\d+")
    if (!is.na(num) && num %in% party_codebook$code) {
      crow <- party_codebook$region[match(num, party_codebook$code)]
      if (crow == "-" || is.na(r) || crow == r) { out[i] <- num; meth[i] <- "code"; next }
    }
    nv <- norm(vt); hit <- NULL
    for (rr in c(r, NA)) {
      cand <- if (is.na(rr)) alias[is.na(alias$region), ] else alias[alias$region == rr | is.na(alias$region), ]
      mm <- cand$code[str_detect(nv, cand$pattern)]; mm <- mm[!is.na(mm)]
      if (length(mm)) { hit <- mm[1]; break }
    }
    if (!is.null(hit)) {
      crow <- party_codebook$region[match(hit, party_codebook$code)]
      if (is.na(r) || crow == "-" || crow == r) { out[i] <- hit; meth[i] <- "alias"; next }
    }
    other_code <- c(GER="7",SUI="19",USA="22",AUS="27",LEB="39",TUR="44")[r]
    if (!is.na(other_code) && str_detect(vt, "(?i)part[yei]|partisi")) {
      out[i] <- other_code; meth[i] <- "other-country"; next
    }
    meth[i] <- "unmatched"
  }
  tibble(code = out, method = meth)
}


smart_parse <- function(x) {
  map_chr(as.character(x), function(v) {
    if (is.na(v)) return(NA_character_)
    if (v == "TRUE") return("1")
    if (v == "FALSE") return("0")
    num <- suppressWarnings(readr::parse_number(v))
    if (!is.na(num)) return(as.character(num))
    str_trim(toupper(v))
  })
}
