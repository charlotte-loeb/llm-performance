library(tidyverse)

# Optional: regenerates the input files of the parent folder from the project repo.
# Run from the project root:  Rscript zero_shot_reliability/preparation/make_input_files.R

out_dir <- here::here("zero_shot_reliability")
input_dir <- here::here("zero_shot_reliability", "preparation")

levels <- list(
  article = list(res = "article_results.csv", man = "text_analysis.csv", ids = "Text_ID",
    vars = c("SECTION", "FORM_OF_PRESENTATION", "TONE", "OPPOSING_POSITIONS")),
  actor = list(res = "actor_results.csv", man = "actor_analysis.csv", ids = c("Text_ID", "ACT_IDX"),
    vars = c("ACT_ROLE_GENERAL", "ACT_GENDER", "ACT_RELIGIOUS_AFFILIATION", "ACT_PARTY_AFFILIATION", "ACT_ORIGIN")),
  justification = list(res = "justification_results.csv", man = "justification_analysis.csv", ids = c("Text_ID", "JUST_IDX"),
    vars = c("JUST_IN_GROUP_REFERENCE", "JUST_OUT_GROUP_REF", "JUST_COMMON_GOOD_REF", "JUST_RELIGIOUS_BELIEFS_REF")),
  actref = list(res = "actref_results.csv", man = "actref_analysis.csv", ids = c("Text_ID", "ACTREF_IDX"),
    vars = c("ACTREF_GENUINE_CONSTRUCTED_RESP_ACTOR", "ACTREF_VALENCE_ACTOR", "ACTREF_RECOGNITION_ACTOR", "ACTREF_OUTRAGE_ACTOR")),
  posref = list(res = "posref_results.csv", man = "position_reference.csv", ids = c("Text_ID", "POSREF_IDX"),
    vars = c("POSREF_GENUINE_CONSTRUCTED_RESP_POSITION", "POSREF_VALENCE_POSITION", "POSREF_RECOGNITION_POSITION", "POSREF_OUTRAGE_POSITION")),
  justref = list(res = "justref_results.csv", man = "justification_reference.csv", ids = c("Text_ID", "JUSTREF_IDX"),
    vars = c("JUSTREF_GENUINE_CONSTRUCTED_RESP_JUSTIFICATION", "JUSTREF_VALENCE_JUSTIFICATION"))
)

country_region <- c("1" = "AUS", "2" = "SUI", "3" = "GER", "4" = "LEB", "5" = "TUR", "6" = "USA")
source(file.path(input_dir, "party_harmonization.R"))

walk(names(levels), \(level) {
  spec <- levels[[level]]
  keep <- c(spec$ids, "COUNTRY", "model", spec$vars)

  zero_shot <- read_csv(here::here("_results_v1", spec$res), show_col_types = FALSE) |>
    mutate(across(everything(), as.character), across(all_of(spec$vars), smart_parse))

  if ("ACT_PARTY_AFFILIATION" %in% spec$vars) {
    zero_shot <- zero_shot |>
      mutate(ACT_PARTY_AFFILIATION = harmonize_party(
        .data$ACT_PARTY_AFFILIATION, unname(country_region[.data$COUNTRY])
      )$code)
  }

  human <- read_csv(here::here("data", spec$man), show_col_types = FALSE) |>
    mutate(across(everything(), as.character))

  zero_shot |> select(all_of(intersect(keep, names(zero_shot)))) |>
    write_tsv(file.path(out_dir, paste0(level, "_zero_shot.tsv")))
  human |> select(all_of(c(spec$ids, spec$vars))) |>
    write_tsv(file.path(out_dir, paste0(level, "_human.tsv")))
})
