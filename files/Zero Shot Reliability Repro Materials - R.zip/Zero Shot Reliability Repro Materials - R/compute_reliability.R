library(tidyverse)
library(tidycomm)

# Inter-coder reliability of the harmonized zero-shot codings against the human
# gold standard: percentage agreement and Krippendorff's alpha per coding task.
# Outputs: reliability.tsv, reliability.rds (same layout as the reported icr_list.rds)

in_dir <- if (file.exists(file.path("data", "article_human.tsv"))) {
  "."
} else {
  here::here("zero_shot_reliability")
}

tasks <- list(
  article = list(ids = "Text_ID", vars = c("SECTION", "FORM_OF_PRESENTATION", "TONE", "OPPOSING_POSITIONS")),
  actor = list(ids = c("Text_ID", "ACT_IDX"), vars = c("ACT_ROLE_GENERAL", "ACT_GENDER",
           "ACT_RELIGIOUS_AFFILIATION", "ACT_PARTY_AFFILIATION", "ACT_ORIGIN")),
  justification = list(ids = c("Text_ID", "JUST_IDX"), vars = c("JUST_IN_GROUP_REFERENCE",
           "JUST_OUT_GROUP_REF", "JUST_COMMON_GOOD_REF", "JUST_RELIGIOUS_BELIEFS_REF")),
  actref = list(ids = c("Text_ID", "ACTREF_IDX"), vars = c("ACTREF_GENUINE_CONSTRUCTED_RESP_ACTOR",
           "ACTREF_VALENCE_ACTOR", "ACTREF_RECOGNITION_ACTOR", "ACTREF_OUTRAGE_ACTOR")),
  posref = list(ids = c("Text_ID", "POSREF_IDX"), vars = c("POSREF_GENUINE_CONSTRUCTED_RESP_POSITION",
           "POSREF_VALENCE_POSITION", "POSREF_RECOGNITION_POSITION", "POSREF_OUTRAGE_POSITION")),
  justref = list(ids = c("Text_ID", "JUSTREF_IDX"), vars = c("JUSTREF_GENUINE_CONSTRUCTED_RESP_JUSTIFICATION",
           "JUSTREF_VALENCE_JUSTIFICATION"))
)

ordinal_vars <- "TONE"
model_labels <- c(gemini_31_flash_lite = "Gemini", gpt_5_nano = "GPT", qwen3 = "Qwen")
level_labels <- c(article = "ARTICLE", actor = "ACTOR", justification = "JUSTIF",
                  actref = "ACT_REF", posref = "POS_REF", justref = "JUST_REF")
consensus <- "LLM-Consensus"

majority <- function(x) {
  values <- unique(na.omit(x))
  if (length(values) == 0) return(NA_character_)
  values[which.max(tabulate(match(x, values)))]
}

read_level <- function(level) {
  spec <- tasks[[level]]

  human <- read_tsv(file.path(in_dir, "data", paste0(level, "_human.tsv")), col_types = cols(.default = "c")) |>
    mutate(across(all_of(spec$vars), ~ na_if(str_trim(.x), "")), coder = "Human")

  machines <- read_tsv(file.path(in_dir, "data", paste0(level, "_zero_shot.tsv")), col_types = cols(.default = "c")) |>
    mutate(across(all_of(spec$vars), ~ na_if(str_trim(.x), "")))

  vote <- machines |>
    group_by(across(all_of(spec$ids))) |>
    summarise(across(all_of(spec$vars), majority), .groups = "drop") |>
    mutate(coder = consensus)

  list(
    human = human,
    vote = vote,
    models = machines |> select(all_of(c(spec$ids, "model", spec$vars))) |> rename(coder = "model")
  )
}

test_icr_safe <- function(units, vars, ordinal) {
  tryCatch(
    test_icr(units, !!sym("unit_id"), !!sym("coder"), all_of(vars), levels = ordinal, na.omit = TRUE),
    error = function(condition) NULL
  )
}

test_comparison <- function(level, coders, comparison) {
  spec <- tasks[[level]]
  ordinal <- if (ordinal_vars %in% spec$vars) c(TONE = "ordinal") else NULL

  units <- coders |> unite("unit_id", all_of(spec$ids), sep = "_", remove = TRUE)

  if (!is.null(ordinal)) {
    units <- units |> mutate(TONE = as.numeric(.data$TONE))
  }

  estimates <- test_icr_safe(units, spec$vars, ordinal)
  if (is.null(estimates)) return(NULL)

  estimates |>
    mutate(Comparison = comparison, Level = unname(level_labels[[level]]), .before = 1)
}

reliability <- names(tasks) |>
  map_dfr(\(level) {
    codings <- read_level(level)
    bind_rows(
      map(names(model_labels), \(model)
        test_comparison(level, bind_rows(codings$human, filter(codings$models, coder == model)),
                        paste0("Human-", model))),
      test_comparison(level, bind_rows(codings$human, codings$vote), paste0("Human-", consensus))
    )
  }) |>
  mutate(
    model = if_else(.data$Comparison == paste0("Human-", consensus), "Majority vote",
                    unname(model_labels[str_remove(.data$Comparison, "Human-")])),
    scale = if_else(.data$Variable %in% ordinal_vars, "ordinal", "nominal")
  )

reliability |>
  transmute(
    level = .data$Level, variable = .data$Variable, scale = .data$scale,
    comparison = .data$Comparison, model = .data$model,
    percent_agreement = .data$Agreement, krippendorffs_alpha = .data$Krippendorffs_Alpha,
    n_units = .data$n_Units, n_coders = .data$n_Coders
  ) |>
  arrange(.data$level, .data$variable, .data$comparison) |>
  write_tsv(file.path(in_dir, "reliability.tsv"))

list(
  res_indiv = reliability |> filter(.data$Comparison != paste0("Human-", consensus)),
  res_consensus = reliability |> filter(.data$Comparison == paste0("Human-", consensus))
) |>
  saveRDS(file.path(in_dir, "reliability.rds"))
