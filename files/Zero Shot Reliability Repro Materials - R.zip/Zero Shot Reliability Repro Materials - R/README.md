# Zero-shot codings → inter-coder reliability

Self-contained replication of the reliability step: harmonized zero-shot codings
plus the human gold standard in, agreement and Krippendorff's alpha out.

## Run

```sh
Rscript compute_reliability.R     # ~15 seconds
```

Requires the tidyverse and `tidycomm`. Everything reads and writes inside this folder.

## Inputs

Twelve tab-separated files, one pair per coding level. All values are text; codes
follow the MedCon codebook (`-99` = not specified).

| file | rows | contents |
|---|---|---|
| `<level>_human.tsv` | human gold standard | unit identifiers and the coded categories |
| `<level>_zero_shot.tsv` | 3 models × sampled units | same columns plus `model` |

Levels: `article`, `actor`, `justification`, `actref`, `posref`, `justref`.
Models: `gemini_31_flash_lite`, `gpt_5_nano`, `qwen3` (February 2026 run).

The zero-shot files are already cleaned: value formats are normalized to codebook
codes, and free-text party names are mapped onto the country-specific party codes.
Party names that are not in the codebook are left missing, so they are neither
agreement nor disagreement.

## Output

- `reliability.tsv` — one row per task and comparison: level, variable, scale
  (nominal/ordinal), comparison, model, percentage agreement, Krippendorff's
  alpha, number of units, number of coders.
- `reliability.rds` — `list(res_indiv, res_consensus)` in the column layout of the
  reported `icr_list.rds`, so the analysis scripts can read it in place of that file.

Four comparisons per task: each model against the human gold standard, and the
majority vote of the three models against it. The majority vote is the modal code
per unit; ties go to the first model alphabetically.

## Notes

- Units enter a task only when both coders have a non-missing code; articles that
  failed to code are therefore treated as missing rather than as errors.
- TONE is the only ordinal variable; alpha there uses the ordinal measurement
  level, all other tasks nominal.
- Verified against `results/icr_list_1_harmonized.rds` (the input to both
  `harmonized_rerun/` folders sent to the coauthors): identical on all 92 cells.
  Against the un-harmonized `_results_v1/icr_list.rds` (the numbers printed in the
  manuscript), only `ACT_PARTY_AFFILIATION`
  differs — consensus alpha .278 → .643.
- For the human–human reliability of the double-coded subsample see
  `results/human_double_coded/`, which uses `irrCAC` because `tidycomm` does not
  scale to the 88-category `ACT_ORIGIN` there.
