############################################################
# MASTER SCRIPT
# LLM-human coding agreement and annotation complexity
#
# Produces every result, table and figure reported in the manuscript and SI
# Appendix.
#
# Sections
#   0) Configuration
#   1) Packages
#   2) Shared helpers (themes, saving, labels)
#   3) Data import, preparation and validation
#        3a) Expert survey -> item-level means, SDs, 95% CIs
#        3b) Expert inter-rater reliability (Krippendorff's alpha, ICC; Table S1)
#        3c) LLM-human reliability (majority vote + individual models)
#        3d) Human ICR
#        3e) Analysis data sets + integrity checks
#   4) Regression models (Blocks 1-3; Parts A-D: alpha / agreement, bivariate and
#      hierarchical)
#   5) SI tables (.docx): Table S1 expert agreement, Tables S2-S13 regressions
#   6) Main-text figures (PNAS print size)
#        Fig. 1  A: need for information x need for interpretation (expert ratings)
#                B: majority-vote LLM-human Krippendorff's alpha per variable
#        Fig. 2  DV = alpha, all models. A/B: bivariate regressions (Blocks 1A, 2A);
#                C: both dimensions jointly (Block 3A, coefficient plot)
#   7) SI figures (PNAS print size)
#        Fig. S1 clarity x completeness of coding instructions
#        Fig. S2 LLM-human alpha and agreement per variable, all models
#        Fig. S3 as Fig. 2, DV = percentage agreement (Blocks 1B, 2B, 3B)
#        Fig. S4 robustness: hierarchical Step-2 models (Blocks 3C/3D), all models
#   8) Legacy large-format figures (optional; slides / working versions)
#   9) Machine-readable results (CSV)
#  10) Robustness checks (optional; Table S14)
#  11) SI tables for the Word SI Appendix (SI_tables.rds) and session info
#
# Data files expected in DATA_DIR:
#   - exsvy_public.sav          expert survey (17 items x 4 dimensions)
#   - icr_list1.rds             LLM-human reliability (res_consensus, res_indiv)
#   - overview_human_icr.sav    human-human (pre-consensus) reliability per variable (optional)
#
# All outputs are written to OUT_DIR.
#
# Scales: percentage agreement (LLM-human and human-human) is analysed on a
# 0-100 scale, so unstandardized coefficients are in percentage points.
############################################################


############################
# 0) CONFIGURATION
############################

PROJECT_DIR <- getwd()   # open the .Rproj, or setwd() to the project folder
DATA_DIR    <- Sys.getenv("MEDCON_DATA_DIR", PROJECT_DIR)
OUT_DIR     <- Sys.getenv("MEDCON_OUT_DIR", file.path(PROJECT_DIR, "_output"))

# Public version of the expert survey (identifying columns removed by
# 00a_make_public_expert_survey.R); gives the same results as exsvy_complete.sav
FILE_EXPERT     <- "exsvy_public.sav"
FILE_ICR        <- "icr_list1.rds"

# Human-human (pre-consensus) reliability per variable; the first file found is used.
# Optional: if none exists, the human-ICR robustness check is skipped.
FILE_HUMAN_ICR_CANDIDATES <- c("overview_ics.sav", "overview_human_icr.sav")
# Column names of the human-human reliability in that file
HUMAN_ALPHA_COL <- "Human_Kripp_Alpha"
HUMAN_AGREE_COL <- "Human_Agreement"

N_ITEMS_EXPECTED <- 17
EXCLUDED_LEVELS  <- c("JUST_REF", "POS_REF")

# Reference lines in the reliability bar charts
ALPHA_REF <- 0.6
AGREE_REF <- 0.8

# Fig. 1B: "alpha" (Krippendorff's alpha only) or c("alpha", "agree") to add
# percentage agreement as panel C
FIG1_BAR_METRICS <- c("alpha")

# Coefficient plots: FALSE = unstandardized B (all four predictors are 1-5 expert
# ratings, so B is directly comparable: change in the outcome per scale point);
# TRUE = standardized beta.
COEF_PLOT_STANDARDIZED <- TRUE   # matches the beta shown in the bivariate panels of Fig. 2

# PNAS print sizes (inches): 1 column = 8.7 cm, 1.5 columns = 11.4 cm, 2 columns = 17.8 cm
PNAS_WIDTH_1COL   <- 3.42
PNAS_WIDTH_1_5COL <- 4.49
PNAS_WIDTH_2COL   <- 7.0
PRINT_BASE_SIZE   <- 7       # pt; PNAS asks for 6-8 pt text at final size

SAVE_SVG <- TRUE
SAVE_PNG <- TRUE                 # 600 dpi PNG, needed for the Word SI Appendix
EXPORT_LEGACY_FIGURES <- FALSE   # TRUE also exports the old large-format figures
RUN_ROBUSTNESS <- TRUE

# SI table numbers. Table S1 = expert agreement, S14 = robustness checks.
# Regression tables are keyed "<block><part>": blocks 1 = need for information,
# 2 = need for interpretation, 3 = both jointly; parts A = alpha, B = agreement,
# C/D = hierarchical with clarity and completeness (alpha / agreement).
SI_TABLE_EXPERT <- 1
SI_TABLE_REG <- c(
  "1A" = 2,  "2A" = 3,  "3A" = 4,    # main models, Krippendorff's alpha
  "1B" = 5,  "2B" = 6,  "3B" = 7,    # main models, percentage agreement
  "1C" = 8,  "2C" = 9,  "3C" = 10,   # + clarity and completeness, alpha
  "1D" = 11, "2D" = 12, "3D" = 13    # + clarity and completeness, agreement
)
SI_TABLE_ROBUST <- 14

dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)


############################
# 1) PACKAGES
############################

suppressPackageStartupMessages({
  library(tidyverse)
  library(haven)
  library(patchwork)   # >= 1.2.0 (axis_titles = "collect")
  library(svglite)
  library(scales)
  library(modelsummary)
  library(flextable)
  library(officer)
  library(car)         # vif(); note: car::recode masks dplyr::recode -> always call dplyr::recode
  library(irr)         # kripp.alpha() for expert agreement
  library(psych)       # ICC() for expert agreement (uses lme4 when ratings are missing)
})


############################
# 2) SHARED HELPERS
############################

# cairo_pdf embeds fonts (required by PNAS) and handles Unicode (–, ², Δ, α, β) reliably
PDF_DEVICE <- if (isTRUE(capabilities("cairo"))) cairo_pdf else "pdf"

save_fig <- function(plot_obj, filename_base, width, height) {
  ggsave(
    filename = file.path(OUT_DIR, paste0(filename_base, ".pdf")),
    plot = plot_obj, width = width, height = height, device = PDF_DEVICE
  )
  if (SAVE_SVG) {
    ggsave(
      filename = file.path(OUT_DIR, paste0(filename_base, ".svg")),
      plot = plot_obj, width = width, height = height, device = svglite::svglite
    )
  }
  if (SAVE_PNG) {   # raster version for the Word SI Appendix (02_make_SI_appendix.R)
    ggsave(
      filename = file.path(OUT_DIR, paste0(filename_base, ".png")),
      plot = plot_obj, width = width, height = height, dpi = 600, bg = "white"
    )
  }
  invisible(plot_obj)
}

pt_to_mm <- function(pt) pt / ggplot2::.pt   # font size in pt -> ggplot text size

# Theme for figures exported at PNAS print size
theme_pnas_print <- function(base_size = PRINT_BASE_SIZE) {
  theme_classic(base_size = base_size) +
    theme(
      text = element_text(color = "black"),
      axis.text = element_text(size = base_size, color = "black"),
      axis.title = element_text(size = base_size + 0.5, color = "black"),
      axis.line = element_line(linewidth = 0.3, color = "black"),
      axis.ticks = element_line(linewidth = 0.3, color = "black"),
      axis.ticks.length = unit(1, "mm"),
      plot.title = element_text(size = base_size + 0.5, face = "bold"),
      plot.subtitle = element_text(size = base_size),
      plot.tag = element_text(size = base_size + 2, face = "bold"),
      strip.background = element_blank(),
      strip.text = element_text(size = base_size, face = "bold", lineheight = 1.1),
      legend.title = element_blank(),
      legend.text = element_text(size = base_size),
      legend.key.size = unit(3, "mm"),
      legend.position = "none",
      plot.margin = margin(3, 4, 3, 3)
    )
}

# Themes for the legacy large-format figures (were two different theme_pnas()
# functions in the original scripts)
theme_pnas_desc <- function(base_size = 11) {
  theme_minimal(base_size = base_size) +
    theme(
      panel.grid.minor = element_blank(),
      panel.grid.major = element_line(color = "grey88", linewidth = 0.3),
      axis.title = element_text(color = "black"),
      axis.text = element_text(color = "black"),
      plot.title = element_text(face = "bold", color = "black"),
      plot.tag = element_text(face = "bold", size = base_size + 1),
      legend.position = "none"
    )
}

theme_pnas_reg <- function() {
  theme_classic(base_size = 12) +
    theme(
      axis.title = element_text(size = 12, color = "black"),
      axis.text = element_text(size = 10.5, color = "black"),
      axis.line = element_line(linewidth = 0.5, color = "black"),
      axis.ticks = element_line(linewidth = 0.4, color = "black"),
      axis.ticks.length = unit(2, "mm"),
      plot.margin = margin(10, 10, 10, 10),
      plot.title = element_text(size = 11.5, face = "bold", color = "black"),
      plot.subtitle = element_text(size = 10.5, color = "black"),
      legend.position = "none"
    )
}

get_model_label <- function(x) {
  case_when(
    str_detect(str_to_lower(x), "gemini") ~ "Gemini",
    str_detect(str_to_lower(x), "gpt") ~ "GPT",
    str_detect(str_to_lower(x), "qwen|gwen") ~ "Qwen",
    TRUE ~ x
  )
}

level_to_group <- function(level) {
  case_when(
    level == "ARTICLE" ~ "Text",
    level == "ACTOR" ~ "Actor",
    level == "JUSTIF" ~ "Justification",
    level %in% c("ACT_REF", "ACTREF") ~ "Reference",
    TRUE ~ NA_character_
  )
}

format_p <- function(p) {
  if (p < .001) "p < 0.001" else paste0("p = ", sprintf("%.3f", p))
}

# Proportions (0-1) -> percent (0-100); leaves data already on 0-100 untouched
to_percent <- function(x) {
  if (all(is.na(x))) return(x)
  if (max(x, na.rm = TRUE) <= 1) x * 100 else x
}

complete_rows <- function(data, vars) {
  data |> filter(if_all(all_of(vars), ~ !is.na(.x)))
}

model_order <- c("Majority vote", "Gemini", "GPT", "Qwen")
group_levels <- c("Text", "Actor", "Justification", "Reference")

group_cols <- c(
  "Text" = "#2F2F2F",
  "Actor" = "#D55E00",
  "Justification" = "#0072B2",
  "Reference" = "#009E73"
)

item_key <- tibble(
  item = c(
    "section", "pres", "tone", "opppos",
    "actrole", "actparty", "actorig", "actgen", "actrel",
    "justin", "justout", "justcg", "justrel",
    "actrefresp", "actrefval", "actrefrec", "actrefout"
  ),
  label = c(
    "Section", "Presentation", "Tone", "Opposing positions",
    "Actor role", "Actor party", "Actor origin", "Actor gender", "Actor religion",
    "Justification in-group", "Justification out-group",
    "Justification common good", "Justification religion",
    "Actor reference responsiveness", "Actor reference valence",
    "Actor reference recognition", "Actor reference outrage"
  ),
  variable_name = c(
    "SECTION", "FORM_OF_PRESENTATION", "TONE", "OPPOSING_POSITIONS",
    "ACT_ROLE_GENERAL", "ACT_PARTY_AFFILIATION", "ACT_ORIGIN", "ACT_GENDER",
    "ACT_RELIGIOUS_AFFILIATION",
    "JUST_IN_GROUP_REFERENCE", "JUST_OUT_GROUP_REF", "JUST_COMMON_GOOD_REF",
    "JUST_RELIGIOUS_BELIEFS_REF",
    "ACTREF_GENUINE_CONSTRUCTED_RESP_ACTOR", "ACTREF_VALENCE_ACTOR",
    "ACTREF_RECOGNITION_ACTOR", "ACTREF_OUTRAGE_ACTOR"
  ),
  group = c(
    rep("Text", 4), rep("Actor", 5), rep("Justification", 4), rep("Reference", 4)
  )
)
stopifnot(nrow(item_key) == N_ITEMS_EXPECTED)


############################
# 3) DATA IMPORT, PREPARATION AND VALIDATION
############################

# ---- 3a) Expert survey -----------------------------------------------------

dims <- c("know", "interpret", "clear", "complete")

read_expert_survey <- function(path) {
  read_sav(path) |> mutate(across(everything(), zap_labels))
}

# Anchored on the 17 known item stems, so unrelated survey columns that
# happen to end in e.g. "complete" are never picked up.
expert_item_regex <- paste0(
  "^(", paste(item_key$item, collapse = "|"), ")(",
  paste(dims, collapse = "|"), ")$"
)

summarise_expert_survey <- function(expert_df) {
  expert_df |>
    select(matches(expert_item_regex)) |>
    pivot_longer(everything(), names_to = "Variable", values_to = "value") |>
    extract(Variable, into = c("item", "type"), regex = expert_item_regex) |>
    group_by(item, type) |>
    summarise(
      M = mean(value, na.rm = TRUE),
      SD = sd(value, na.rm = TRUE),
      N = sum(!is.na(value)),
      CI = qt(0.975, df = N - 1) * SD / sqrt(N),   # half-width of the 95% CI of the mean
      .groups = "drop"
    ) |>
    pivot_wider(
      names_from = type,
      values_from = c(M, SD, N, CI),
      names_glue = "{.value}_{type}"
    )
}

expert_raw <- read_expert_survey(file.path(DATA_DIR, FILE_EXPERT))

expert_summary <- summarise_expert_survey(expert_raw) |>
  right_join(item_key, by = "item") |>
  mutate(
    SD_mean_know_interpret = (SD_know + SD_interpret) / 2,
    SD_mean_all4 = (SD_know + SD_interpret + SD_clear + SD_complete) / 4,
    diff_interpret_minus_know = M_interpret - M_know,
    diff_complete_minus_clear = M_complete - M_clear
  )

missing_items <- expert_summary |>
  filter(if_any(c(M_know, M_interpret, M_clear, M_complete), is.na)) |>
  pull(item)
if (length(missing_items) > 0) {
  stop("Expert survey: no ratings found for item(s): ", paste(missing_items, collapse = ", "))
}

n_experts_total <- expert_raw |>
  select(matches(expert_item_regex)) |>
  filter(if_any(everything(), ~ !is.na(.x))) |>
  nrow()

message(sprintf(
  "Expert survey: %d experts with at least one rating; N per item and dimension ranges from %d to %d.",
  n_experts_total,
  min(select(expert_summary, starts_with("N_"))),
  max(select(expert_summary, starts_with("N_")))
))

# Item-level predictors for the regressions
expert_means <- expert_summary |>
  transmute(
    Variable = variable_name,
    mean_know = M_know,
    mean_interpret = M_interpret,
    mean_clear = M_clear,
    mean_complete = M_complete
  )

# Item order and numbering shared by all figures (Text, Actor, Justification, Reference;
# alphabetical within group)
item_ids <- expert_summary |>
  mutate(group = factor(group, levels = group_levels)) |>
  arrange(group, label) |>
  mutate(
    id = row_number(),
    id_label = sprintf("%02d", id),
    id_name = paste(id_label, label)
  ) |>
  select(variable_name, id, id_label, id_name, label, group)

# ---- 3b) Expert inter-rater reliability ------------------------------------
# Agreement among experts across the 17 variables, per rating dimension.
# Krippendorff's alpha (interval) matches the reliability metric used for coders;
# ICC(2,k) is the reliability of the averaged rating, i.e. of the predictor
# that enters the regressions. Low values would attenuate regression coefficients.

expert_reliability <- map_dfr(dims, function(d) {
  ratings <- expert_raw |>
    select(all_of(paste0(item_key$item, d))) |>
    as.matrix()
  ratings <- ratings[rowSums(!is.na(ratings)) > 0, , drop = FALSE]   # raters x items

  ka <- irr::kripp.alpha(ratings, method = "interval")$value

  icc <- tryCatch(
    suppressMessages(suppressWarnings(psych::ICC(t(ratings), missing = TRUE, lmer = TRUE)))$results,
    error = function(e) {
      warning("ICC for dimension '", d, "' failed: ", conditionMessage(e))
      NULL
    }
  )
  get_icc <- function(type, col) if (is.null(icc)) NA_real_ else icc[icc$type == type, col]

  tibble(
    dimension = d,
    n_experts = nrow(ratings),
    n_items = ncol(ratings),
    kripp_alpha_interval = ka,
    icc2_single = get_icc("ICC2", "ICC"),
    icc2k_average = get_icc("ICC2k", "ICC"),
    icc2k_ci_low = get_icc("ICC2k", "lower bound"),
    icc2k_ci_high = get_icc("ICC2k", "upper bound")
  )
})

write_csv(expert_reliability, file.path(OUT_DIR, "Results_expert_reliability.csv"))
message("Expert agreement (Krippendorff's alpha, interval / ICC(2,k)): ",
        paste(sprintf("%s = %.2f / %.2f", expert_reliability$dimension,
                      expert_reliability$kripp_alpha_interval, expert_reliability$icc2k_average),
              collapse = "; "))

# ---- 3c) LLM-human reliability ---------------------------------------------

icr_list <- readRDS(file.path(DATA_DIR, FILE_ICR))

# Agreement stays on its original 0-1 scale here (used for the bar charts);
# it is rescaled to 0-100 for the regressions in 3e.
llm_majority <- icr_list[["res_consensus"]] |>
  filter(!Level %in% EXCLUDED_LEVELS) |>
  mutate(model_name = "Majority vote")

llm_indiv <- icr_list[["res_indiv"]] |>
  filter(!Level %in% EXCLUDED_LEVELS) |>
  mutate(model_name = get_model_label(Comparison))

unknown_models <- setdiff(unique(llm_indiv$model_name), model_order)
if (length(unknown_models) > 0) {
  warning("Unrecognised model label(s) in res_indiv$Comparison: ", paste(unknown_models, collapse = ", "))
}

llm_all <- bind_rows(llm_majority, llm_indiv) |>
  mutate(model_name = factor(model_name, levels = model_order))

if (max(llm_all$Agreement, na.rm = TRUE) > 1) {
  stop("LLM-human Agreement exceeds 1; expected proportions (0-1). Check icr_list.")
}

# ---- 3d) Human ICR ---------------------------------------------------------

human_icr_found <- FILE_HUMAN_ICR_CANDIDATES[file.exists(file.path(DATA_DIR, FILE_HUMAN_ICR_CANDIDATES))]
HAS_HUMAN_ICR <- length(human_icr_found) > 0

if (HAS_HUMAN_ICR) {
  FILE_HUMAN_ICR <- human_icr_found[1]
  human_icr <- read_sav(file.path(DATA_DIR, FILE_HUMAN_ICR)) |>
    mutate(across(everything(), zap_labels))

  missing_human_cols <- setdiff(c("Variable", HUMAN_ALPHA_COL, HUMAN_AGREE_COL), names(human_icr))
  if (length(missing_human_cols) > 0) {
    stop(sprintf(
      "%s: column(s) %s not found. Available columns: %s. Set HUMAN_ALPHA_COL / HUMAN_AGREE_COL in the configuration.",
      FILE_HUMAN_ICR, paste(missing_human_cols, collapse = ", "), paste(names(human_icr), collapse = ", ")
    ))
  }

  human_icr <- human_icr |>
    rename(Human_Kripp_Alpha = all_of(HUMAN_ALPHA_COL), Human_Agreement = all_of(HUMAN_AGREE_COL)) |>
    mutate(Human_Agreement = to_percent(Human_Agreement))

  if (anyDuplicated(human_icr$Variable)) {
    stop(FILE_HUMAN_ICR, " has duplicated values in 'Variable'; the join would duplicate rows.")
  }
  message("Human-human reliability read from '", FILE_HUMAN_ICR, "'.")
} else {
  warning("No human-human reliability file found (", paste(FILE_HUMAN_ICR_CANDIDATES, collapse = " / "),
          "): the human-ICR robustness check is skipped.")
  human_icr <- tibble(Variable = character(), Human_Kripp_Alpha = numeric(), Human_Agreement = numeric())
}
clash <- setdiff(intersect(names(human_icr), names(icr_list[["res_indiv"]])), "Variable")
if (length(clash) > 0) {
  stop("Column name clash between human ICR and LLM ICR data: ", paste(clash, collapse = ", "))
}

# ---- 3e) Analysis data sets ------------------------------------------------

build_analysis_set <- function(llm_df) {
  llm_df |>
    left_join(human_icr, by = "Variable", relationship = "many-to-one") |>
    left_join(expert_means, by = "Variable", relationship = "many-to-one") |>
    rename(
      LLM_Human_Kripp_Alpha = Krippendorffs_Alpha,
      LLM_Human_Agreement = Agreement
    ) |>
    mutate(LLM_Human_Agreement = LLM_Human_Agreement * 100)   # percentage points
}

df_majority_analysis <- build_analysis_set(llm_majority)
df_indiv_analysis <- build_analysis_set(llm_indiv)

analysis_sets <- list(
  "Majority vote" = df_majority_analysis,
  "Gemini" = df_indiv_analysis |> filter(model_name == "Gemini"),
  "GPT" = df_indiv_analysis |> filter(model_name == "GPT"),
  "Qwen" = df_indiv_analysis |> filter(model_name == "Qwen")
)

# Integrity checks: one row per coded variable, all expert predictors present
iwalk(analysis_sets, function(d, nm) {
  if (anyDuplicated(d$Variable)) {
    stop(nm, ": variable(s) occur more than once after filtering levels: ",
         paste(unique(d$Variable[duplicated(d$Variable)]), collapse = ", "))
  }
  if (nrow(d) != N_ITEMS_EXPECTED) {
    warning(sprintf("%s: %d variables in analysis set (expected %d).", nm, nrow(d), N_ITEMS_EXPECTED))
  }
  no_expert <- d$Variable[is.na(d$mean_know) | is.na(d$mean_interpret)]
  if (length(no_expert) > 0) {
    warning(nm, ": no expert ratings matched for ", paste(no_expert, collapse = ", "))
  }
  no_human <- d$Variable[is.na(d$Human_Kripp_Alpha) | is.na(d$Human_Agreement)]
  if (HAS_HUMAN_ICR && length(no_human) > 0) {
    warning(nm, ": no human-human reliability matched for ", paste(no_human, collapse = ", "),
            " (excluded from the human-ICR robustness check)")
  }
})

message("Analysis sets (n variables): ",
        paste(names(analysis_sets), map_int(analysis_sets, nrow), sep = " = ", collapse = "; "))

cor_know_interpret <- cor.test(expert_summary$M_know, expert_summary$M_interpret)
message(sprintf("Item-level r(need for information, need for interpretation) = %.2f, %s",
                cor_know_interpret$estimate, format_p(cor_know_interpret$p.value)))


############################
# 4) REGRESSION MODELS
############################

run_regression_report <- function(data, dv, predictors, model_label) {
  formula_obj <- as.formula(paste(dv, "~", paste(predictors, collapse = " + ")))
  model <- lm(formula_obj, data = data)
  model_sum <- summary(model)
  f_stat <- model_sum$fstatistic

  list(
    label = model_label,
    model = model,
    model_summary = model_sum,
    vif_values = if (length(predictors) > 1) car::vif(model) else NULL,
    n = nobs(model),
    r2 = model_sum$r.squared,
    adj_r2 = model_sum$adj.r.squared,
    f_value = unname(f_stat[1]),
    df1 = unname(f_stat[2]),
    df2 = unname(f_stat[3]),
    model_p = pf(f_stat[1], f_stat[2], f_stat[3], lower.tail = FALSE)
  )
}

run_standardized_model <- function(data, dv, predictors) {
  df_std <- data |>
    select(all_of(c(dv, predictors))) |>
    drop_na() |>
    mutate(across(everything(), ~ as.numeric(scale(.x))))
  lm(as.formula(paste(dv, "~", paste(predictors, collapse = " + "))), data = df_std)
}

run_hierarchical_models <- function(data, dv, step1_predictors, step2_predictors, model_label) {
  model1 <- lm(as.formula(paste(dv, "~", paste(step1_predictors, collapse = " + "))), data = data)
  model2 <- lm(as.formula(paste(dv, "~", paste(c(step1_predictors, step2_predictors), collapse = " + "))), data = data)
  comp <- anova(model1, model2)
  r2_1 <- summary(model1)$r.squared
  r2_2 <- summary(model2)$r.squared

  list(
    label = model_label,
    step1 = model1,
    step2 = model2,
    r2_step1 = r2_1,
    r2_step2 = r2_2,
    delta_r2 = r2_2 - r2_1,
    f_change = comp$F[2],
    p_change = comp$`Pr(>F)`[2],
    df_change_1 = comp$Df[2],
    df_change_2 = comp$Res.Df[2],
    vif_step2 = car::vif(model2)
  )
}

COVARIATES <- c("mean_clear", "mean_complete")                 # instruction quality (Parts C/D)

dv_info <- list(
  alpha = list(
    var = "LLM_Human_Kripp_Alpha",
    label = "LLM–human Krippendorff's alpha",
    axis = "LLM–human Krippendorff's α",
    unit = "change in α per scale point"
  ),
  agree = list(
    var = "LLM_Human_Agreement",
    label = "LLM–human percentage agreement",
    axis = "LLM–human agreement (%)",
    unit = "percentage points per scale point"
  )
)

# Parts A-D (SI table numbers: SI_TABLE_REG in the configuration)
step2_instructions <- list(
  covariates = COVARIATES,
  panel = "+ clarity and completeness",
  note = "Step 2 adds clarity and completeness of instructions."
)

part_info <- list(
  A = list(dv = "alpha", hier = FALSE),
  B = list(dv = "agree", hier = FALSE),
  C = c(list(dv = "alpha", hier = TRUE), step2 = list(step2_instructions)),
  D = c(list(dv = "agree", hier = TRUE), step2 = list(step2_instructions))
)

block_info <- list(
  "1" = list(
    ivs = "mean_know",
    iv_label = "Need for information",
    iv_text = "need for information",
    step1_panel = "Need for information",
    step1_note = "need for information only"
  ),
  "2" = list(
    ivs = "mean_interpret",
    iv_label = "Need for interpretation",
    iv_text = "need for interpretation",
    step1_panel = "Need for interpretation",
    step1_note = "need for interpretation only"
  ),
  "3" = list(
    ivs = c("mean_know", "mean_interpret"),
    iv_label = "Need for information and need for interpretation",
    iv_text = "need for information and need for interpretation",
    step1_panel = "Need for information + need for interpretation",
    step1_note = "need for information and need for interpretation"
  )
)

fit_part <- function(block, part) {
  dv <- dv_info[[part$dv]]$var
  ivs <- block$ivs

  if (!part$hier) {
    vars <- c(dv, ivs)
    list(
      unstd = imap(analysis_sets, ~ run_regression_report(complete_rows(.x, vars), dv, ivs, .y)),
      std = map(analysis_sets, ~ run_standardized_model(complete_rows(.x, vars), dv, ivs))
    )
  } else {
    # Step 1 and Step 2 (unstandardized and standardized) all use the same
    # estimation sample: complete cases on DV, IVs and covariates.
    covs <- part$step2$covariates
    vars <- c(dv, ivs, covs)
    list(
      hier = imap(analysis_sets, ~ run_hierarchical_models(complete_rows(.x, vars), dv, ivs, covs, .y)),
      std_step1 = map(analysis_sets, ~ run_standardized_model(complete_rows(.x, vars), dv, ivs)),
      std_step2 = map(analysis_sets, ~ run_standardized_model(complete_rows(.x, vars), dv, c(ivs, covs)))
    )
  }
}

results <- map(block_info, function(block) map(part_info, ~ fit_part(block, .x)))
# Access e.g. results[["2"]][["C"]]$hier[["GPT"]]$step2


############################
# 5) SI TABLES (.docx)
############################
# Files are named TableS<nn>_<content>.docx; numbers are set in the configuration.

coef_labels_all_unstd <- c(
  "(Intercept)" = "Intercept",
  "Human_Kripp_Alpha" = "Human Krippendorff's alpha",
  "Human_Agreement" = "Human percentage agreement",
  "mean_know" = "Need for information",
  "mean_interpret" = "Need for interpretation",
  "mean_clear" = "Clarity of instructions",
  "mean_complete" = "Completeness of instructions"
)
coef_labels_all_std <- coef_labels_all_unstd[-1]
coef_labels_hier <- coef_labels_all_unstd[c("mean_know", "mean_interpret", "mean_clear", "mean_complete")]

gof_map_table <- tibble::tribble(
  ~raw,            ~clean,          ~fmt,
  "nobs",          "Observations",  0,
  "r.squared",     "R²",            3,
  "adj.r.squared", "Adjusted R²",   3
)

style_regression_flextable <- function(ft, n_models, panel_title) {
  ft |>
    add_header_lines(values = panel_title) |>
    theme_booktabs() |>
    autofit() |>
    align(align = "left", part = "all") |>
    align(j = 2:(n_models + 1), align = "center", part = "all") |>
    bold(part = "header") |>
    fontsize(size = 10, part = "all") |>
    padding(padding = 4, part = "all")
}

make_modelsummary_ft <- function(models, coef_map, panel_title) {
  ft <- modelsummary(
    models,
    coef_map = coef_map,
    estimate = "{estimate}{stars}",
    statistic = "[{conf.low}, {conf.high}]",
    stars = c("*" = .05, "**" = .01, "***" = .001),
    gof_map = gof_map_table,
    fmt = 3,
    output = "flextable"
  )
  style_regression_flextable(ft, length(models), panel_title)
}

make_change_stats_ft <- function(hier_list, panel_title) {
  df <- map_dfr(hier_list, function(x) {
    tibble(
      Model = x$label,
      `R² Step 1` = round(x$r2_step1, 3),
      `R² Step 2` = round(x$r2_step2, 3),
      `ΔR²` = round(x$delta_r2, 3),
      `F-change` = round(x$f_change, 3),
      df1 = x$df_change_1,
      df2 = x$df_change_2,
      p = format.pval(x$p_change, digits = 3, eps = .001)
    )
  })

  flextable(df) |>
    add_header_lines(values = panel_title) |>
    theme_booktabs() |>
    autofit() |>
    align(align = "center", part = "all") |>
    bold(part = "header") |>
    fontsize(size = 10, part = "all") |>
    padding(padding = 4, part = "all")
}

# Plain data frame -> styled flextable (Tables S1, S14)
make_plain_ft <- function(df, panel_title = NULL) {
  ft <- flextable(df)
  if (!is.null(panel_title)) ft <- add_header_lines(ft, values = panel_title)
  ft |>
    theme_booktabs() |>
    autofit() |>
    align(align = "left", j = 1:2, part = "all") |>
    bold(part = "header") |>
    fontsize(size = 10, part = "all") |>
    padding(padding = 4, part = "all")
}

fmt_num <- function(x, digits = 3) ifelse(is.na(x), "", formatC(x, format = "f", digits = digits))
fmt_pval <- function(p) ifelse(is.na(p), "", ifelse(p < .001, "< 0.001", formatC(p, format = "f", digits = 3)))

si_table_file <- function(no, content) sprintf("TableS%02d_%s.docx", no, content)

# Every SI table is also collected here and saved to SI_tables.rds (section 11),
# from which 02_make_SI_appendix.R assembles the SI Appendix
si_tables <- list()

build_regression_doc <- function(file_name, table_title, ft_list, note_text) {
  si_tables[[file_name]] <<- list(title = table_title, ft_list = ft_list, note = note_text)
  doc <- read_docx() |>
    body_add_par(table_title, style = "heading 1") |>
    body_add_par("", style = "Normal")
  for (ft in ft_list) {
    doc <- doc |> body_add_flextable(ft) |> body_add_par("", style = "Normal")
  }
  doc <- body_add_par(doc, note_text, style = "Normal")
  print(doc, target = file.path(OUT_DIR, file_name))
}

COLUMNS_NOTE <- "Columns report majority-vote LLM coding, Gemini, GPT, and Qwen, respectively."
STARS_NOTE <- "* p < 0.05, ** p < 0.01, *** p < 0.001."
AGREE_NOTE <- "Percentage agreement ranges from 0 to 100; unstandardized coefficients are in percentage points."

for (b in names(block_info)) {
  block <- block_info[[b]]
  for (p in names(part_info)) {
    part <- part_info[[p]]
    res <- results[[b]][[p]]
    dv_label <- dv_info[[part$dv]]$label
    table_no <- paste0("S", SI_TABLE_REG[[paste0(b, p)]])
    scale_note <- if (part$dv == "agree") AGREE_NOTE else NULL

    if (!part$hier) {
      ft_list <- list(
        make_modelsummary_ft(map(res$unstd, "model"), coef_labels_all_unstd,
                             "Panel A. Unstandardized coefficients"),
        make_modelsummary_ft(res$std, coef_labels_all_std,
                             "Panel B. Standardized coefficients")
      )
      table_title <- sprintf("Table %s. %s predicting %s", table_no, block$iv_label, dv_label)
      note_text <- paste(c(
        sprintf("Note. Models regress %s on %s.", dv_label, block$iv_text),
        COLUMNS_NOTE,
        "Panel A reports unstandardized coefficients with 95% confidence intervals in brackets.",
        "Panel B reports standardized coefficients with 95% confidence intervals in brackets.",
        scale_note,
        STARS_NOTE
      ), collapse = " ")
    } else {
      ft_list <- list(
        make_modelsummary_ft(map(res$hier, "step1"), coef_labels_all_unstd,
                             paste0("Panel A. Step 1 (unstandardized): ", block$step1_panel)),
        make_modelsummary_ft(map(res$hier, "step2"), coef_labels_all_unstd,
                             paste0("Panel B. Step 2 (unstandardized): ", part$step2$panel)),
        make_modelsummary_ft(res$std_step1, coef_labels_all_std,
                             "Panel C. Step 1 (standardized)"),
        make_modelsummary_ft(res$std_step2, coef_labels_all_std,
                             "Panel D. Step 2 (standardized)"),
        make_change_stats_ft(res$hier, "Panel E. Hierarchical change statistics")
      )
      table_title <- sprintf("Table %s. Hierarchical models predicting %s", table_no, dv_label)
      note_text <- paste(c(
        sprintf("Note. Step 1 includes %s.", block$step1_note),
        part$step2$note,
        "Panel E reports formal hierarchical model change statistics (ΔR² and F-change).",
        COLUMNS_NOTE,
        scale_note,
        STARS_NOTE
      ), collapse = " ")
    }

    build_regression_doc(
      file_name = si_table_file(SI_TABLE_REG[[paste0(b, p)]], paste0("Block", b, p)),
      table_title = table_title,
      ft_list = ft_list,
      note_text = note_text
    )
  }
}

# ---- Table S1: agreement among the experts (from 3b) -----------------------

dim_labels <- c(
  know = "Need for information",
  interpret = "Need for interpretation",
  clear = "Clarity of instructions",
  complete = "Completeness of instructions"
)

tableS1_df <- expert_reliability |>
  transmute(
    Dimension = dim_labels[dimension],
    Experts = n_experts,
    Variables = n_items,
    `Krippendorff's α (interval)` = fmt_num(kripp_alpha_interval, 2),
    `ICC(2,1)` = fmt_num(icc2_single, 2),
    `ICC(2,k)` = fmt_num(icc2k_average, 2),
    `ICC(2,k) 95% CI` = sprintf("[%s, %s]", fmt_num(icc2k_ci_low, 2), fmt_num(icc2k_ci_high, 2))
  )

build_regression_doc(
  file_name = si_table_file(SI_TABLE_EXPERT, "expert_agreement"),
  table_title = sprintf("Table S%d. Agreement among the experts on the four rating dimensions", SI_TABLE_EXPERT),
  ft_list = list(make_plain_ft(tableS1_df)),
  note_text = paste(
    "Note. Agreement across the 17 variables per rating dimension (1-5 scales).",
    "Krippendorff's alpha uses the interval metric. Intraclass correlations are from a two-way",
    "random-effects model: ICC(2,1) is the reliability of a single expert's rating, ICC(2,k) the",
    "reliability of the mean rating across all experts, which is the predictor used in the regressions."
  )
)


############################
# FIGURE BUILDING BLOCKS (print size)
############################

# ---- Expert-rating scatterplot (Fig. 1A, Fig. S1) ---------------------------
# Error bars: 95% CI of the item mean (t-based), in both dimensions.

expert_plot_df <- expert_summary |>
  select(-label, -group) |>
  inner_join(item_ids, by = "variable_name") |>
  mutate(group = factor(group, levels = group_levels))

make_expert_scatter <- function(xvar, yvar, xlab, ylab,
                                base_size = PRINT_BASE_SIZE,
                                circle_size = 4.6,
                                theme_fun = theme_pnas_print) {
  ci_x <- sub("^M_", "CI_", xvar)
  ci_y <- sub("^M_", "CI_", yvar)

  ggplot(expert_plot_df, aes(x = .data[[xvar]], y = .data[[yvar]])) +
    annotate("rect", xmin = 1, xmax = 3, ymin = 1, ymax = 3, fill = "grey97", color = NA) +
    annotate("rect", xmin = 3, xmax = 5, ymin = 3, ymax = 5, fill = "grey94", color = NA) +
    geom_vline(xintercept = 3, linetype = "dashed", color = "grey60", linewidth = 0.3) +
    geom_hline(yintercept = 3, linetype = "dashed", color = "grey60", linewidth = 0.3) +
    geom_errorbar(
      aes(ymin = .data[[yvar]] - .data[[ci_y]], ymax = .data[[yvar]] + .data[[ci_y]]),
      width = 0, color = "grey65", linewidth = 0.3
    ) +
    geom_errorbar(
      aes(xmin = .data[[xvar]] - .data[[ci_x]], xmax = .data[[xvar]] + .data[[ci_x]]),
      orientation = "y", width = 0, color = "grey65", linewidth = 0.3
    ) +
    geom_point(aes(fill = group), shape = 21, size = circle_size, stroke = 0.2, color = "white") +
    geom_text(aes(label = id_label), color = "white",
              size = pt_to_mm(base_size - 1), fontface = "bold") +
    scale_fill_manual(values = group_cols, drop = FALSE) +
    scale_x_continuous(breaks = 1:5) +
    scale_y_continuous(breaks = 1:5) +
    coord_fixed(xlim = c(1, 5), ylim = c(1, 5), expand = FALSE, clip = "off") +
    labs(x = xlab, y = ylab) +
    theme_fun(base_size)
}

# ---- Horizontal reliability bars (Fig. 1B, Fig. S2) ------------------------

bar_data <- llm_all |>
  inner_join(item_ids, by = c("Variable" = "variable_name")) |>
  mutate(
    id_name = factor(id_name, levels = rev(sort(unique(id_name)))),
    group = factor(group, levels = group_levels)
  )

unmatched_bars <- setdiff(unique(llm_all$Variable), item_ids$variable_name)
if (length(unmatched_bars) > 0) {
  warning("LLM reliability rows without an item label (not plotted): ", paste(unmatched_bars, collapse = ", "))
}

bar_metric_info <- list(
  alpha = list(var = "Krippendorffs_Alpha", axis = "LLM–human Krippendorff's α",
               lims = c(-0.4, 1), breaks = seq(-0.4, 1, 0.2), ref = ALPHA_REF,
               labels = label_number(accuracy = 0.1)),
  agree = list(var = "Agreement", axis = "LLM–human agreement",
               lims = c(0, 1), breaks = seq(0, 1, 0.2), ref = AGREE_REF,
               labels = label_percent(accuracy = 1))
)

make_reliability_bars <- function(data, metric, show_labels = TRUE, facet = FALSE) {
  mi <- bar_metric_info[[metric]]
  # extend the lower limit (in steps of 0.2) so negative values are shown, not clipped
  lowest <- min(data[[mi$var]], na.rm = TRUE)
  if (lowest < mi$lims[1]) {
    mi$lims[1] <- floor(lowest * 5) / 5
    mi$breaks <- seq(mi$lims[1], mi$lims[2], 0.2)
  }
  out_of_range <- data[[mi$var]] < mi$lims[1] | data[[mi$var]] > mi$lims[2]
  if (any(out_of_range, na.rm = TRUE)) {
    warning(sprintf("Bar chart (%s): %d value(s) outside the axis range and clipped.",
                    metric, sum(out_of_range, na.rm = TRUE)))
  }

  p <- ggplot(data, aes(x = .data[[mi$var]], y = id_name, fill = group)) +
    geom_col(width = 0.7) +
    geom_vline(xintercept = 0, color = "black", linewidth = 0.3) +
    geom_vline(xintercept = mi$ref, linetype = "dashed", color = "grey45", linewidth = 0.3) +
    scale_fill_manual(values = group_cols, drop = FALSE) +
    scale_x_continuous(breaks = if (facet) c(0, 0.5, 1) else mi$breaks, labels = mi$labels) +
    coord_cartesian(xlim = mi$lims) +
    labs(x = mi$axis, y = NULL) +
    theme_pnas_print() +
    theme(
      axis.line.y = element_blank(),
      axis.ticks.y = element_blank(),
      panel.spacing.x = unit(4, "mm")
    )

  if (!show_labels) p <- p + theme(axis.text.y = element_blank())
  if (facet) p <- p + facet_wrap(~model_name, nrow = 1)
  p
}

group_legend_theme <- theme(
  legend.position = "bottom",
  legend.justification = "center",
  legend.margin = margin(0, 0, 0, 0)
)

# ---- Coefficient plots (Fig. 2C, Fig. S3C, Fig. S4) ------------------------

tidy_lm <- function(model) {
  s <- coef(summary(model))
  ci <- confint(model)
  tibble(
    term = rownames(s),
    estimate = s[, 1], se = s[, 2], t = s[, 3], p = s[, 4],
    conf.low = ci[, 1], conf.high = ci[, 2],
    n = nobs(model),
    r2 = summary(model)$r.squared,
    adj_r2 = summary(model)$adj.r.squared
  )
}

coef_models_for <- function(b, p, standardized = COEF_PLOT_STANDARDIZED) {
  res <- results[[b]][[p]]
  if (part_info[[p]]$hier) {
    if (standardized) res$std_step2 else map(res$hier, "step2")
  } else {
    if (standardized) res$std else map(res$unstd, "model")
  }
}

coef_axis_label <- function(dv_key, standardized = COEF_PLOT_STANDARDIZED) {
  if (standardized) "Standardized coefficient (β, 95% CI)"
  else paste0("Coefficient (95% CI)\n", dv_info[[dv_key]]$unit)
}

make_coef_plot_print <- function(models, xlab, facet = TRUE) {
  plot_df <- imap_dfr(models, ~ tidy_lm(.x) |> mutate(model_name = .y)) |>
    filter(term != "(Intercept)") |>
    mutate(
      model_name = factor(model_name, levels = model_order),
      term_label = factor(dplyr::recode(term, !!!coef_labels_hier), levels = rev(coef_labels_hier))
    )

  p <- ggplot(plot_df, aes(x = estimate, y = term_label)) +
    geom_vline(xintercept = 0, linetype = "dashed", color = "grey60", linewidth = 0.3) +
    geom_errorbar(aes(xmin = conf.low, xmax = conf.high),
                  orientation = "y", width = 0.2, linewidth = 0.4) +
    geom_point(shape = 21, size = 2, fill = "grey25", color = "black", stroke = 0.3) +
    labs(x = xlab, y = NULL) +
    theme_pnas_print()

  if (facet) p <- p + facet_wrap(~model_name, nrow = 1)
  p
}

# ---- Bivariate regression panels (Fig. 2A/B, Fig. S3A/B) -------------------
# Statistics (standardized beta = r for one predictor, p) sit in the panel strip,
# so they never overlap data points.

make_bivariate_row <- function(iv, iv_label, dv_key) {
  dv <- dv_info[[dv_key]]$var

  d <- imap_dfr(analysis_sets, ~ complete_rows(.x, c(iv, dv)) |>
                  select(Variable, all_of(c(iv, dv))) |>
                  mutate(model_name = .y))

  strips <- d |>
    group_by(model_name) |>
    summarise(
      strip = {
        ct <- cor.test(.data[[iv]], .data[[dv]])
        sprintf("%s\nβ = %.2f, %s", first(model_name), ct$estimate, format_p(ct$p.value))
      },
      .groups = "drop"
    ) |>
    mutate(model_name = factor(model_name, levels = model_order)) |>
    arrange(model_name)

  d <- d |>
    left_join(strips |> mutate(model_name = as.character(model_name)), by = "model_name") |>
    mutate(strip = factor(strip, levels = strips$strip))

  y_scale <- if (dv_key == "agree") scale_y_continuous(labels = function(x) paste0(x, "%")) else scale_y_continuous()

  ggplot(d, aes(x = .data[[iv]], y = .data[[dv]])) +
    geom_smooth(method = "lm", formula = y ~ x, se = TRUE,
                color = "black", fill = "grey85", linewidth = 0.5) +
    geom_point(shape = 21, size = 1.4, stroke = 0.2, fill = "grey35", color = "black") +
    facet_wrap(~strip, nrow = 1) +
    y_scale +
    labs(x = paste0(iv_label, " (expert mean)"), y = dv_info[[dv_key]]$axis) +
    theme_pnas_print()
}


############################
# 6) MAIN-TEXT FIGURES (PNAS print size)
############################

# ---- Fig. 1: expert ratings (A) + majority-vote LLM-human reliability (B[, C]) ----

fig1_A <- make_expert_scatter(
  "M_know", "M_interpret",
  "Need for information (expert mean)", "Need for interpretation (expert mean)"
)

fig1_bars <- map(seq_along(FIG1_BAR_METRICS), function(i) {
  make_reliability_bars(
    bar_data |> filter(model_name == "Majority vote"),
    FIG1_BAR_METRICS[i],
    show_labels = i == 1
  ) + guides(fill = "none")   # group legend comes from panel A
})

fig1 <- wrap_plots(c(list(fig1_A), fig1_bars), nrow = 1,
                   widths = c(1, rep(if (length(fig1_bars) == 1) 1.1 else 0.75, length(fig1_bars)))) +
  plot_layout(guides = "collect") +
  plot_annotation(tag_levels = "A") &
  group_legend_theme

save_fig(fig1, "Fig1_expert_ratings_majority_reliability", PNAS_WIDTH_2COL, 3.6)

# ---- Fig. 2: bivariate panels (Blocks 1A, 2A) + joint model (Block 3A) ------
# Same layout is reused for percentage agreement in Fig. S3.
#   A: need for information -> outcome (bivariate), four models
#   B: need for interpretation -> outcome (bivariate), four models
#   C: both dimensions entered jointly (coefficient plot), four models

make_complexity_figure <- function(dv_key) {
  joint_part <- c(alpha = "A", agree = "B")[[dv_key]]   # Block 3
  row_title <- function(txt) labs(title = txt)

  (make_bivariate_row("mean_know", "Need for information", dv_key) +
     row_title("Bivariate: need for information")) /
    (make_bivariate_row("mean_interpret", "Need for interpretation", dv_key) +
       row_title("Bivariate: need for interpretation")) /
    (make_coef_plot_print(coef_models_for("3", joint_part), coef_axis_label(dv_key)) +
       row_title("Joint model: both dimensions")) +
    plot_layout(heights = c(1, 1, 0.75)) +
    plot_annotation(tag_levels = "A")
}

save_fig(make_complexity_figure("alpha"), "Fig2_bivariate_and_joint_alpha", PNAS_WIDTH_2COL, 6.6)


############################
# 7) SI FIGURES (PNAS print size)
############################

# ---- Fig. S1: clarity x completeness, with item key -------------------------

key_df <- item_ids |>
  arrange(id) |>
  mutate(y = rev(id), group = factor(group, levels = group_levels))

p_key_print <- ggplot(key_df, aes(y = y)) +
  geom_point(aes(x = 1, fill = group), shape = 21, size = 4.6, stroke = 0.2, color = "white") +
  geom_text(aes(x = 1, label = id_label), color = "white",
            size = pt_to_mm(PRINT_BASE_SIZE - 1), fontface = "bold") +
  geom_text(aes(x = 1.25, label = label), hjust = 0, size = pt_to_mm(PRINT_BASE_SIZE)) +
  scale_fill_manual(values = group_cols) +
  scale_x_continuous(limits = c(0.9, 4)) +
  scale_y_continuous(limits = c(0.5, nrow(key_df) + 0.5)) +
  theme_void(base_size = PRINT_BASE_SIZE) +
  theme(legend.position = "none")

figS1 <- make_expert_scatter(
  "M_clear", "M_complete",
  "Clarity of coding instructions (expert mean)", "Completeness of coding instructions (expert mean)"
) + p_key_print + plot_layout(widths = c(1, 0.9))

save_fig(figS1, "FigS1_clarity_completeness", PNAS_WIDTH_1_5COL + 1, 3.2)

# ---- Fig. S2: LLM-human reliability per variable, all models ----------------

figS2 <- (make_reliability_bars(bar_data, "alpha", facet = TRUE) /
            make_reliability_bars(bar_data, "agree", facet = TRUE)) +
  plot_layout(guides = "collect") +
  plot_annotation(tag_levels = "A") &
  group_legend_theme

save_fig(figS2, "FigS2_LLM_reliability_all_models", PNAS_WIDTH_2COL, 6.5)

# ---- Fig. S3: as Fig. 2, for percentage agreement --------------------------

save_fig(make_complexity_figure("agree"), "FigS3_bivariate_and_joint_agreement", PNAS_WIDTH_2COL, 6.6)

# ---- Fig. S4: robustness, hierarchical Step 2 (Blocks 3C alpha, 3D agreement) ----

figS4 <- (make_coef_plot_print(coef_models_for("3", "C"), coef_axis_label("alpha")) /
            make_coef_plot_print(coef_models_for("3", "D"), coef_axis_label("agree"))) +
  plot_annotation(tag_levels = "A")

save_fig(figS4, "FigS4_robustness_hierarchical_coef", PNAS_WIDTH_2COL, 3.6)


############################
# 8) LEGACY LARGE-FORMAT FIGURES (optional)
############################
# Same content as the original scripts' figures (for slides / working versions),
# with the fixes applied: 95% CI error bars, percent axis for agreement,
# shared x-axis titles, statistics in subtitles, no clipped coefficient CIs.

if (EXPORT_LEGACY_FIGURES) {

  # Fig. 1a-c (old layout)
  p_key_legacy <- ggplot(key_df, aes(y = y)) +
    geom_point(aes(x = 1, fill = group), shape = 21, size = 6, stroke = 0.3, color = "white") +
    geom_text(aes(x = 1, label = id_label), color = "white", size = 2.6, fontface = "bold") +
    geom_text(aes(x = 1.22, label = label), hjust = 0, size = 3.1) +
    scale_fill_manual(values = group_cols) +
    xlim(0.88, 2.85) +
    ylim(0.5, nrow(key_df) + 0.5) +
    theme_void(base_size = 11) +
    theme(legend.position = "none")

  legacy_A <- make_expert_scatter("M_know", "M_interpret",
                                  "Need for information (mean)", "Need for interpretation (mean)",
                                  base_size = 11, circle_size = 6, theme_fun = theme_pnas_desc)
  legacy_B <- make_expert_scatter("M_clear", "M_complete",
                                  "Clarity of coding instructions (mean)", "Completeness of coding instructions (mean)",
                                  base_size = 11, circle_size = 6, theme_fun = theme_pnas_desc)

  save_fig(legacy_A + p_key_legacy + plot_layout(widths = c(1.35, 1)), "Figure1a_scatter_IV_key", 11.5, 6.8)
  save_fig(legacy_B + p_key_legacy + plot_layout(widths = c(1.35, 1)), "Figure1b_scatter_COV_key", 11.5, 6.8)
  save_fig(legacy_A + legacy_B + p_key_legacy + plot_layout(widths = c(1.05, 1.05, 1.2)),
           "Figure1c_scatter_IV_COV_key", 15, 6.8)

  # LLM-human reliability bar charts (one file per model + panels)
  make_llm_barplot_legacy <- function(data, metric, title) {
    mi <- bar_metric_info[[metric]]
    ggplot(data |> arrange(id), aes(x = factor(label, levels = item_ids$label[order(item_ids$id)]),
                                    y = .data[[mi$var]], fill = group)) +
      geom_col(width = 0.7) +
      geom_hline(yintercept = mi$ref, linetype = "dashed", color = "grey45", linewidth = 0.5) +
      scale_fill_manual(values = group_cols) +
      scale_y_continuous(breaks = mi$breaks, labels = mi$labels) +
      coord_cartesian(ylim = mi$lims) +
      labs(x = "Variable", y = mi$axis, title = title) +
      theme_pnas_desc(11) +
      theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))
  }

  bar_files <- c("Majority vote" = "majority", "Gemini" = "gemini", "GPT" = "gpt", "Qwen" = "qwen")
  for (metric in c("alpha", "agree")) {
    plots <- map(model_order, function(m) {
      make_llm_barplot_legacy(bar_data |> filter(model_name == m), metric,
                              paste0(LETTERS[match(m, model_order)], ": ", m))
    })
    suffix <- if (metric == "alpha") "alpha" else "agreement"
    walk2(plots, model_order, ~ save_fig(.x, paste0("llm_", bar_files[[.y]], "_", suffix), 8, 8))
    save_fig(wrap_plots(plots, ncol = 4), paste0("Figure_llm_", suffix, "_panel"), 18, 7)
  }

  # Regression scatter panels (Blocks 1 and 2), four models in a row
  make_four_panel_legacy <- function(iv, iv_label, dv_key, tags, block_title) {
    dv <- dv_info[[dv_key]]$var
    data_list <- map(analysis_sets, ~ complete_rows(.x, c(iv, dv)))
    xlim <- range(unlist(map(data_list, iv)), na.rm = TRUE)
    ylim <- range(unlist(map(data_list, dv)), na.rm = TRUE)

    panels <- imap(data_list, function(d, nm) {
      i <- match(nm, model_order)
      ct <- cor.test(d[[iv]], d[[dv]])
      ggplot(d, aes(x = .data[[iv]], y = .data[[dv]])) +
        geom_point(shape = 21, size = 2.8, stroke = 0.3, fill = "grey35", color = "black", alpha = 0.9) +
        geom_smooth(method = "lm", formula = y ~ x, se = TRUE, color = "black", fill = "grey88", linewidth = 0.7) +
        coord_cartesian(xlim = xlim, ylim = ylim) +
        labs(x = iv_label, y = dv_info[[dv_key]]$axis,
             title = paste0(tags[i], ": ", nm),
             subtitle = sprintf("β = %.2f, %s", ct$estimate, format_p(ct$p.value))) +
        theme_pnas_reg() +
        if (i > 1) theme(axis.text.y = element_blank(), axis.ticks.y = element_blank()) else theme()
    })
    wrap_plots(panels, ncol = 4) +
      plot_layout(axis_titles = "collect") +
      plot_annotation(title = block_title)
  }

  legacy_scatter <- list()
  for (b in c("1", "2")) {
    block <- block_info[[b]]
    for (p in c("A", "B")) {
      dv_key <- part_info[[p]]$dv
      tags <- if (p == "A") c("A", "B", "C", "D") else c("E", "F", "G", "H")
      legacy_scatter[[paste0(b, p)]] <- make_four_panel_legacy(
        block$ivs, block$iv_label, dv_key, tags,
        sprintf("Block %s%s. %s predicting %s", b, p, block$iv_label, dv_info[[dv_key]]$label)
      )
      save_fig(legacy_scatter[[paste0(b, p)]],
               sprintf("Figure_Block%s%s_%s_panel", b, p, if (p == "A") "alpha" else "agreement"),
               16, 4.8)
    }
    save_fig(legacy_scatter[[paste0(b, "A")]] / legacy_scatter[[paste0(b, "B")]],
             sprintf("Figure_Block%sAB_combined", b), 16, 9.5)
  }

  # Coefficient plots, one file per block/part
  coef_plot_specs <- tribble(
    ~block, ~part, ~type,
    "1", "C", "Hierarchical",
    "1", "D", "Hierarchical",
    "2", "C", "Hierarchical",
    "2", "D", "Hierarchical",
    "3", "A", "Multivariate",
    "3", "B", "Multivariate",
    "3", "C", "Hierarchical",
    "3", "D", "Hierarchical"
  )
  pwalk(coef_plot_specs, function(block, part, type) {
    dv_key <- part_info[[part]]$dv
    fig <- make_coef_plot_print(coef_models_for(block, part), coef_axis_label(dv_key)) +
      labs(title = sprintf("Block %s%s. %s models predicting %s", block, part, type, dv_info[[dv_key]]$label)) +
      theme_pnas_print(base_size = 11)
    save_fig(fig, sprintf("Figure_Block%s%s_coef", block, part), 16, 5.2)
  })
}


############################
# 9) MACHINE-READABLE RESULTS
############################

all_coefs <- imap_dfr(results, function(block_res, b) {
  imap_dfr(block_res, function(res, p) {
    models <- if (part_info[[p]]$hier) {
      list(
        "step1_unstd" = map(res$hier, "step1"),
        "step2_unstd" = map(res$hier, "step2"),
        "step1_std" = res$std_step1,
        "step2_std" = res$std_step2
      )
    } else {
      list("unstd" = map(res$unstd, "model"), "std" = res$std)
    }
    dv_var <- dv_info[[part_info[[p]]$dv]]$var
    imap_dfr(models, function(ml, spec) {
      # .env: tidy_lm() output has a column named `p`, which would mask the part label
      imap_dfr(ml, ~ tidy_lm(.x) |> mutate(llm = .y, .before = 1)) |>
        mutate(block = .env$b, part = .env$p, dv = .env$dv_var, spec = .env$spec, .before = 1)
    })
  })
})
write_csv(all_coefs, file.path(OUT_DIR, "Results_all_model_coefficients.csv"))

hier_change <- imap_dfr(results, function(block_res, b) {
  hier_parts <- names(part_info)[map_lgl(part_info, "hier")]
  imap_dfr(block_res[hier_parts], function(res, p) {
    map_dfr(res$hier, ~ tibble(
      llm = .x$label, r2_step1 = .x$r2_step1, r2_step2 = .x$r2_step2,
      delta_r2 = .x$delta_r2, f_change = .x$f_change,
      df1 = .x$df_change_1, df2 = .x$df_change_2, p_change = .x$p_change,
      max_vif_step2 = max(.x$vif_step2)
    )) |> mutate(block = .env$b, part = .env$p, .before = 1)
  })
})
write_csv(hier_change, file.path(OUT_DIR, "Results_hierarchical_change_stats.csv"))

write_csv(
  expert_summary |>
    left_join(item_ids |> select(variable_name, id), by = "variable_name") |>
    arrange(id) |>
    select(id, item, variable_name, label, group,
           starts_with("M_"), starts_with("SD_"), starts_with("CI_"), starts_with("N_")),
  file.path(OUT_DIR, "Results_expert_item_summary.csv")
)


############################
# 10) ROBUSTNESS CHECKS (optional)
############################
# With n = 17 variables per model, single influential variables and
# heteroscedasticity matter. Reviewers will also ask whether need for
# interpretation merely captures general difficulty, which human ICR controls for.

if (RUN_ROBUSTNESS) {

  robust_rows <- list()

  # (a) HC3 standard errors for the Block 3 models
  if (requireNamespace("sandwich", quietly = TRUE) && requireNamespace("lmtest", quietly = TRUE)) {
    for (p in c("A", "B")) {
      part_lbl <- p
      for (nm in names(analysis_sets)) {
        m <- results[["3"]][[p]]$unstd[[nm]]$model
        ct <- lmtest::coeftest(m, vcov. = sandwich::vcovHC(m, type = "HC3"))
        robust_rows[[length(robust_rows) + 1]] <- tibble(
          check = "HC3 standard errors", block = "3", part = part_lbl, llm = nm,
          term = rownames(ct), estimate = ct[, 1], se = ct[, 2], p = ct[, 4]
        )
      }
    }
  } else {
    message("Robustness: install 'sandwich' and 'lmtest' for HC3 standard errors.")
  }

  # (b) Leave-one-variable-out: range of the Block 3 coefficients
  for (p in c("A", "B")) {
    part_lbl <- p
    dv <- dv_info[[part_info[[p]]$dv]]$var
    for (nm in names(analysis_sets)) {
      d <- complete_rows(analysis_sets[[nm]], c(dv, "mean_know", "mean_interpret"))
      loo <- map_dfr(seq_len(nrow(d)), function(i) {
        m <- lm(as.formula(paste(dv, "~ mean_know + mean_interpret")), data = d[-i, ])
        s <- coef(summary(m))
        tibble(dropped = d$Variable[i], term = rownames(s), estimate = s[, 1], p = s[, 4])
      })
      robust_rows[[length(robust_rows) + 1]] <- loo |>
        filter(term != "(Intercept)") |>
        group_by(term) |>
        summarise(
          estimate_min = min(estimate), estimate_max = max(estimate),
          p_max = max(p),
          dropped_at_p_max = dropped[which.max(p)],
          .groups = "drop"
        ) |>
        mutate(check = "Leave-one-variable-out", block = "3", part = .env$part_lbl, llm = nm, .before = 1)
    }
  }

  # (c) Controlling for human-human reliability of the same variable
  human_ctrl <- c(A = "Human_Kripp_Alpha", B = "Human_Agreement")
  for (p in c("A", "B")) {
    part_lbl <- p
    dv <- dv_info[[part_info[[p]]$dv]]$var
    ctrl <- human_ctrl[[p]]
    if (!HAS_HUMAN_ICR) {
      message("Robustness: no human-human reliability file; skipping human-ICR control.")
      next
    }
    for (nm in names(analysis_sets)) {
      preds <- c("mean_know", "mean_interpret", ctrl)
      d <- complete_rows(analysis_sets[[nm]], c(dv, preds))
      m <- lm(as.formula(paste(dv, "~", paste(preds, collapse = " + "))), data = d)
      robust_rows[[length(robust_rows) + 1]] <- tidy_lm(m) |>
        mutate(check = "Control for human ICR", block = "3", part = .env$part_lbl, llm = nm, .before = 1)
    }
  }

  robustness <- bind_rows(robust_rows)
  write_csv(robustness, file.path(OUT_DIR, "Results_robustness_checks.csv"))

  # ---- Table S14: robustness checks for the joint models (Block 3A/3B) ------
  outcome_labels <- c(A = "Krippendorff's alpha", B = "Percentage agreement")
  var_labels <- setNames(item_ids$label, item_ids$variable_name)

  rob_wide <- function(check_name, cell_fun) {
    robustness |>
      filter(check == check_name, term != "(Intercept)") |>
      mutate(
        cell = cell_fun(pick(everything())),
        # human-human reliability is in the outcome's metric: one column for both outcomes
        term = if_else(startsWith(term, "Human_"), "Human–human reliability",
                       dplyr::recode(term, !!!coef_labels_all_unstd))
      ) |>
      select(part, llm, term, cell) |>
      pivot_wider(names_from = term, values_from = cell) |>
      mutate(
        Outcome = outcome_labels[part],
        Model = factor(llm, levels = model_order),
        .before = 1
      ) |>
      arrange(Outcome, Model) |>
      mutate(Model = as.character(Model)) |>
      select(-part, -llm)
  }
  b_se_p <- function(d) sprintf("%s (%s), p %s", fmt_num(d$estimate), fmt_num(d$se),
                                ifelse(d$p < .001, "< 0.001", paste("=", fmt_pval(d$p))))

  ftS14 <- list()
  if (any(robustness$check == "HC3 standard errors")) {
    ftS14 <- c(ftS14, list(make_plain_ft(
      rob_wide("HC3 standard errors", b_se_p),
      "Panel A. Heteroskedasticity-consistent (HC3) standard errors: B (SE), p"
    )))
  }
  loo_df <- robustness |>
    filter(check == "Leave-one-variable-out") |>
    mutate(range = sprintf("[%s, %s]", fmt_num(estimate_min), fmt_num(estimate_max)))
  loo_tab <- loo_df |>
    arrange(factor(term, levels = c("mean_know", "mean_interpret"))) |>
    mutate(term = dplyr::recode(term, !!!coef_labels_all_unstd)) |>
    select(part, llm, term, range) |>
    pivot_wider(names_from = term, values_from = range, names_glue = "{term}: range of B") |>
    left_join(
      loo_df |>
        filter(term == "mean_interpret") |>
        transmute(part, llm, `Need for interpretation: largest p (variable left out)` =
                    sprintf("%s (%s)", fmt_pval(p_max), var_labels[dropped_at_p_max])),
      by = c("part", "llm")
    ) |>
    mutate(Outcome = outcome_labels[part], Model = factor(llm, levels = model_order), .before = 1) |>
    arrange(Outcome, Model) |>
    mutate(Model = as.character(Model)) |>
    select(-part, -llm)
  ftS14 <- c(ftS14, list(make_plain_ft(loo_tab, "Panel B. Leave-one-variable-out (17 re-estimations per model)")))
  if (any(robustness$check == "Control for human ICR")) {
    ftS14 <- c(ftS14, list(make_plain_ft(
      rob_wide("Control for human ICR", b_se_p),
      "Panel C. Controlling for human–human (pre-consensus) reliability: B (SE), p"
    )))
  }

  build_regression_doc(
    file_name = si_table_file(SI_TABLE_ROBUST, "robustness_checks"),
    table_title = sprintf("Table S%d. Robustness checks for the joint models of need for information and need for interpretation",
                          SI_TABLE_ROBUST),
    ft_list = ftS14,
    note_text = paste(
      "Note. All panels refer to the models including need for information and need for interpretation",
      sprintf("jointly (Tables S%d and S%d), estimated for majority-vote LLM coding, Gemini, GPT, and Qwen.",
              SI_TABLE_REG[["3A"]], SI_TABLE_REG[["3B"]]),
      "Unstandardized coefficients (B); for percentage agreement, B is in percentage points per scale point.",
      "Panel B reports the range of coefficients when each of the 17 variables is left out in turn, and the",
      "largest p value for need for interpretation with the variable whose exclusion produced it.",
      "Panel C adds the human–human reliability of each variable in the same metric as the outcome",
      "(Krippendorff's alpha or percentage agreement, 0-100)."
    )
  )
}


############################
# 11) SI TABLES (RDS) AND SESSION INFO
############################

saveRDS(si_tables[order(names(si_tables))], file.path(OUT_DIR, "SI_tables.rds"))
writeLines(capture.output(sessionInfo()), file.path(OUT_DIR, "sessionInfo.txt"))
message("Done. Outputs written to: ", normalizePath(OUT_DIR))
